export type userLoginDTO = {
    email: string;
    password: string;
};
