export enum Feelings {
    "ANGRY",
    "OK",
    "HAPPY",
    "VERY HAPPY",
    "AMAZING",
}
