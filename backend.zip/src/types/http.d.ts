import { FastifyReply, FastifyRequest } from "fastify";

export type Request = FastifyRequest;
export type Response = FastifyReply;
